# gamebrain.Model.SearchResponseResultsInnerRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mean** | **decimal** |  | [optional] 
**Count** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

