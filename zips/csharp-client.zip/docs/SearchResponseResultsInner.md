# gamebrain.Model.SearchResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | [optional] 
**Year** | **decimal** |  | [optional] 
**Name** | **string** |  | [optional] 
**Genre** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Link** | **string** |  | [optional] 
**Rating** | [**SearchResponseResultsInnerRating**](SearchResponseResultsInnerRating.md) |  | [optional] 
**AdultOnly** | **bool** |  | [optional] 
**Screenshots** | **List&lt;string&gt;** |  | [optional] 
**MicroTrailer** | **string** |  | [optional] 
**Gameplay** | **string** |  | [optional] 
**ShortDescription** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

