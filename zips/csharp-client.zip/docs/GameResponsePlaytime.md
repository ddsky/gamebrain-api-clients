# gamebrain.Model.GameResponsePlaytime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Percentiles** | **List&lt;int&gt;** |  | [optional] 
**Min** | **int** |  | [optional] 
**Median** | **int** |  | [optional] 
**Max** | **int** |  | [optional] 
**Mean** | **float** |  | [optional] 
**Mentions** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

