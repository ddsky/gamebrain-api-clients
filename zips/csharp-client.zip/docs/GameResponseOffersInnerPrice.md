# gamebrain.Model.GameResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currency** | **string** |  | [optional] 
**DiscountPercent** | **float** |  | [optional] 
**Value** | **float** |  | [optional] 
**Initial** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

