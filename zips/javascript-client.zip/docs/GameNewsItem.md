# GamebrainJs.GameNewsItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**url** | **String** |  | 
**source** | **String** |  | 
**image** | **String** |  | [optional] 
**published** | **Date** |  | 


