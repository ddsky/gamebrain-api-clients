# GamebrainJs.SearchResponseActiveFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | [optional] 
**connection** | **String** |  | [optional] 
**values** | [**[SearchResponseActiveFilterOptionsInnerValuesInner]**](SearchResponseActiveFilterOptionsInnerValuesInner.md) |  | [optional] 


