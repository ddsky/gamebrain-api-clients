# GamebrainJs.SimilarGamesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[SearchResponseResultsInner]**](SearchResponseResultsInner.md) |  | [optional] 


