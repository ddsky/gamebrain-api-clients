# GamebrainJs.GameResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**meanPlayers** | **Number** |  | [optional] 
**countPlayers** | **Number** |  | [optional] 
**meanCritics** | **Number** |  | [optional] 
**countCritics** | **Number** |  | [optional] 


