# GamebrainJs.SearchSuggestionResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**year** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**genre** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**link** | **String** |  | [optional] 
**rating** | [**SearchResponseResultsInnerRating**](SearchResponseResultsInnerRating.md) |  | [optional] 
**adultOnly** | **Boolean** |  | [optional] 


