# GamebrainJs.SearchResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**key** | **String** |  | [optional] 
**values** | [**[SearchResponseFilterOptionsInnerValuesInner]**](SearchResponseFilterOptionsInnerValuesInner.md) |  | [optional] 


