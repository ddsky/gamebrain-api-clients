# GamebrainJs.GameResponsePlaytime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentiles** | **[Number]** |  | [optional] 
**min** | **Number** |  | [optional] 
**median** | **Number** |  | [optional] 
**max** | **Number** |  | [optional] 
**mean** | **Number** |  | [optional] 
**mentions** | **Number** |  | [optional] 


