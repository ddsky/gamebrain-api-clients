# GamebrainJs.SearchResponseResultsInnerRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 


