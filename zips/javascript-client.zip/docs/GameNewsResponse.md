# GamebrainJs.GameNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**[GameNewsItem]**](GameNewsItem.md) |  | 


