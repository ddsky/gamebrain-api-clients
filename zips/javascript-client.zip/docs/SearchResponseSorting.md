# GamebrainJs.SearchResponseSorting

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | [optional] 
**direction** | **String** |  | [optional] 


