# GamebrainJs.SearchSuggestionResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[SearchSuggestionResponseResultsInner]**](SearchSuggestionResponseResultsInner.md) |  | [optional] 


