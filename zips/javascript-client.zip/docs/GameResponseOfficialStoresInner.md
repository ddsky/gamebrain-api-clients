# GamebrainJs.GameResponseOfficialStoresInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **String** |  | [optional] 
**url** | **String** |  | [optional] 


