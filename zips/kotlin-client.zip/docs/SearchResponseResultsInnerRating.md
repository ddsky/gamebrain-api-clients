
# SearchResponseResultsInnerRating

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **mean** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **count** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



