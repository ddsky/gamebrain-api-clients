
# GameNewsItem

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  |
| **url** | [**java.net.URI**](java.net.URI.md) |  |  |
| **source** | **kotlin.String** |  |  |
| **published** | [**java.time.LocalDate**](java.time.LocalDate.md) |  |  |
| **image** | [**java.net.URI**](java.net.URI.md) |  |  [optional] |



