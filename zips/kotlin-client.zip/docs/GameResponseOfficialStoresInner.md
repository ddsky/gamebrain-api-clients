
# GameResponseOfficialStoresInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **source** | **kotlin.String** |  |  [optional] |
| **url** | [**java.net.URI**](java.net.URI.md) |  |  [optional] |



