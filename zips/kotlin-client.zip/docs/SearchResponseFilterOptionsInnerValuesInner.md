
# SearchResponseFilterOptionsInnerValuesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **key** | **kotlin.String** |  |  [optional] |
| **count** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



