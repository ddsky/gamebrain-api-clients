
# GameResponseOffersInnerPrice

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **currency** | **kotlin.String** |  |  [optional] |
| **discountPercent** | **kotlin.Float** |  |  [optional] |
| **&#x60;value&#x60;** | **kotlin.Float** |  |  [optional] |
| **initial** | **kotlin.Float** |  |  [optional] |



