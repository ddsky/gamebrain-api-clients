
# SearchResponseFilterOptionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **key** | **kotlin.String** |  |  [optional] |
| **propertyValues** | [**kotlin.collections.List&lt;SearchResponseFilterOptionsInnerValuesInner&gt;**](SearchResponseFilterOptionsInnerValuesInner.md) |  |  [optional] |



