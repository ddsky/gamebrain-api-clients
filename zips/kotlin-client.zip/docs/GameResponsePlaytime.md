
# GameResponsePlaytime

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **percentiles** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional] |
| **min** | **kotlin.Int** |  |  [optional] |
| **median** | **kotlin.Int** |  |  [optional] |
| **max** | **kotlin.Int** |  |  [optional] |
| **mean** | **kotlin.Float** |  |  [optional] |
| **mentions** | **kotlin.Int** |  |  [optional] |



