
# SearchResponseSortingOptionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **sort** | **kotlin.String** |  |  [optional] |
| **key** | **kotlin.String** |  |  [optional] |



