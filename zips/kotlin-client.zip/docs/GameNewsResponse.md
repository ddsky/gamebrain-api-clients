
# GameNewsResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **news** | [**kotlin.collections.List&lt;GameNewsItem&gt;**](GameNewsItem.md) |  |  |



