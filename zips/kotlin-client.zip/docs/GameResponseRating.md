
# GameResponseRating

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **mean** | **kotlin.Float** |  |  [optional] |
| **count** | **kotlin.Int** |  |  [optional] |
| **meanPlayers** | **kotlin.Float** |  |  [optional] |
| **countPlayers** | **kotlin.Int** |  |  [optional] |
| **meanCritics** | **kotlin.Float** |  |  [optional] |
| **countCritics** | **kotlin.Int** |  |  [optional] |



