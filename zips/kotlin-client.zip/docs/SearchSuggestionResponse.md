
# SearchSuggestionResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **results** | [**kotlin.collections.List&lt;SearchSuggestionResponseResultsInner&gt;**](SearchSuggestionResponseResultsInner.md) |  |  [optional] |



