
# SearchResponseActiveFilterOptionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **key** | **kotlin.String** |  |  [optional] |
| **connection** | **kotlin.String** |  |  [optional] |
| **propertyValues** | [**kotlin.collections.List&lt;SearchResponseActiveFilterOptionsInnerValuesInner&gt;**](SearchResponseActiveFilterOptionsInnerValuesInner.md) |  |  [optional] |



