
# GameResponseOffersInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **price** | [**GameResponseOffersInnerPrice**](GameResponseOffersInnerPrice.md) |  |  [optional] |
| **storeName** | **kotlin.String** |  |  [optional] |
| **platform** | **kotlin.String** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **url** | [**java.net.URI**](java.net.URI.md) |  |  [optional] |



