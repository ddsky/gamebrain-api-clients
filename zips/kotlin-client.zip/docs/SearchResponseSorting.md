
# SearchResponseSorting

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **key** | **kotlin.String** |  |  [optional] |
| **direction** | **kotlin.String** |  |  [optional] |



