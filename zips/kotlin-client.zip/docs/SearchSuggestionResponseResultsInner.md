
# SearchSuggestionResponseResultsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  [optional] |
| **year** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **name** | **kotlin.String** |  |  [optional] |
| **genre** | **kotlin.String** |  |  [optional] |
| **image** | [**java.net.URI**](java.net.URI.md) |  |  [optional] |
| **link** | **kotlin.String** |  |  [optional] |
| **rating** | [**SearchResponseResultsInnerRating**](SearchResponseResultsInnerRating.md) |  |  [optional] |
| **adultOnly** | **kotlin.Boolean** |  |  [optional] |



