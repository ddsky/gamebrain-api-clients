# # SearchResponseActiveFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **string** |  | [optional]
**connection** | **string** |  | [optional]
**values** | [**\OpenAPI\Client\Model\SearchResponseActiveFilterOptionsInnerValuesInner[]**](SearchResponseActiveFilterOptionsInnerValuesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
