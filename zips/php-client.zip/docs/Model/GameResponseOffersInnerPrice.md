# # GameResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **string** |  | [optional]
**discount_percent** | **float** |  | [optional]
**value** | **float** |  | [optional]
**initial** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
