# # GameResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | **float** |  | [optional]
**count** | **int** |  | [optional]
**mean_players** | **float** |  | [optional]
**count_players** | **int** |  | [optional]
**mean_critics** | **float** |  | [optional]
**count_critics** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
