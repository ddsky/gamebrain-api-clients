# # SearchResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional]
**year** | **float** |  | [optional]
**name** | **string** |  | [optional]
**genre** | **string** |  | [optional]
**image** | **string** |  | [optional]
**link** | **string** |  | [optional]
**rating** | [**\OpenAPI\Client\Model\SearchResponseResultsInnerRating**](SearchResponseResultsInnerRating.md) |  | [optional]
**adult_only** | **bool** |  | [optional]
**screenshots** | **string[]** |  | [optional]
**micro_trailer** | **string** |  | [optional]
**gameplay** | **string** |  | [optional]
**short_description** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
