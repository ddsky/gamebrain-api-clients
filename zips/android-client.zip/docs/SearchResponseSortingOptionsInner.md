

# SearchResponseSortingOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**sort** | **String** |  |  [optional]
**key** | **String** |  |  [optional]




