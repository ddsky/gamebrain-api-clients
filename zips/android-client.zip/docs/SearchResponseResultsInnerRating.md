

# SearchResponseResultsInnerRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**count** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




