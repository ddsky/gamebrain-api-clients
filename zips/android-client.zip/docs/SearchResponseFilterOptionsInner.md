

# SearchResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**key** | **String** |  |  [optional]
**values** | [**List&lt;SearchResponseFilterOptionsInnerValuesInner&gt;**](SearchResponseFilterOptionsInnerValuesInner.md) |  |  [optional]




