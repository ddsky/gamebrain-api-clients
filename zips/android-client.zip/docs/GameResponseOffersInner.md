

# GameResponseOffersInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | [**GameResponseOffersInnerPrice**](GameResponseOffersInnerPrice.md) |  |  [optional]
**storeName** | **String** |  |  [optional]
**platform** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**url** | [**URI**](URI.md) |  |  [optional]




