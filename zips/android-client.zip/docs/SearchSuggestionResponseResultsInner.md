

# SearchSuggestionResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**year** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**name** | **String** |  |  [optional]
**genre** | **String** |  |  [optional]
**image** | [**URI**](URI.md) |  |  [optional]
**link** | **String** |  |  [optional]
**rating** | [**SearchResponseResultsInnerRating**](SearchResponseResultsInnerRating.md) |  |  [optional]
**adultOnly** | **Boolean** |  |  [optional]




