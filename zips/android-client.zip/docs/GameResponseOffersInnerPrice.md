

# GameResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **String** |  |  [optional]
**discountPercent** | **Float** |  |  [optional]
**value** | **Float** |  |  [optional]
**initial** | **Float** |  |  [optional]




