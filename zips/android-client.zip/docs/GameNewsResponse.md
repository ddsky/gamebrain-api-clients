

# GameNewsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**List&lt;GameNewsItem&gt;**](GameNewsItem.md) |  | 




