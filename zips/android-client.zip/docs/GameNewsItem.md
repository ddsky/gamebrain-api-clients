

# GameNewsItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**url** | [**URI**](URI.md) |  | 
**source** | **String** |  | 
**image** | [**URI**](URI.md) |  |  [optional]
**published** | [**Date**](Date.md) |  | 




