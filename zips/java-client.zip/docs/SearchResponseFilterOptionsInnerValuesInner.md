

# SearchResponseFilterOptionsInnerValuesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**key** | **String** |  |  [optional] |
|**count** | **BigDecimal** |  |  [optional] |



