

# GameResponsePlaytime


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**percentiles** | **List&lt;Integer&gt;** |  |  [optional] |
|**min** | **Integer** |  |  [optional] |
|**median** | **Integer** |  |  [optional] |
|**max** | **Integer** |  |  [optional] |
|**mean** | **Float** |  |  [optional] |
|**mentions** | **Integer** |  |  [optional] |



