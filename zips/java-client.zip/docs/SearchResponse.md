

# SearchResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**sorting** | [**SearchResponseSorting**](SearchResponseSorting.md) |  |  [optional] |
|**activeFilterOptions** | [**List&lt;SearchResponseActiveFilterOptionsInner&gt;**](SearchResponseActiveFilterOptionsInner.md) |  |  [optional] |
|**query** | **String** |  |  [optional] |
|**totalResults** | **Integer** |  |  [optional] |
|**limit** | **Integer** |  |  [optional] |
|**offset** | **Integer** |  |  [optional] |
|**results** | [**List&lt;SearchResponseResultsInner&gt;**](SearchResponseResultsInner.md) |  |  [optional] |
|**filterOptions** | [**List&lt;SearchResponseFilterOptionsInner&gt;**](SearchResponseFilterOptionsInner.md) |  |  [optional] |
|**sortingOptions** | [**List&lt;SearchResponseSortingOptionsInner&gt;**](SearchResponseSortingOptionsInner.md) |  |  [optional] |



