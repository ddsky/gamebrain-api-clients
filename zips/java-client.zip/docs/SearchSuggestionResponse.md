

# SearchSuggestionResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**results** | [**List&lt;SearchSuggestionResponseResultsInner&gt;**](SearchSuggestionResponseResultsInner.md) |  |  [optional] |



