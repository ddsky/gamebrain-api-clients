

# GameNewsItem


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**title** | **String** |  |  |
|**url** | **URI** |  |  |
|**source** | **String** |  |  |
|**image** | **URI** |  |  [optional] |
|**published** | **LocalDate** |  |  |



