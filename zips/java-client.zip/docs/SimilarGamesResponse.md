

# SimilarGamesResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**results** | [**List&lt;SearchResponseResultsInner&gt;**](SearchResponseResultsInner.md) |  |  [optional] |



