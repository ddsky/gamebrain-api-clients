

# GameResponsePlatformsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**value** | **String** |  |  [optional] |
|**name** | **String** |  |  [optional] |



