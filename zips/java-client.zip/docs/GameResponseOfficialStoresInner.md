

# GameResponseOfficialStoresInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**source** | **String** |  |  [optional] |
|**url** | **URI** |  |  [optional] |



