

# SearchResponseActiveFilterOptionsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**key** | **String** |  |  [optional] |
|**connection** | **String** |  |  [optional] |
|**values** | [**List&lt;SearchResponseActiveFilterOptionsInnerValuesInner&gt;**](SearchResponseActiveFilterOptionsInnerValuesInner.md) |  |  [optional] |



