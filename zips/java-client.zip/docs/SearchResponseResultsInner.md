

# SearchResponseResultsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  [optional] |
|**year** | **BigDecimal** |  |  [optional] |
|**name** | **String** |  |  [optional] |
|**genre** | **String** |  |  [optional] |
|**image** | **URI** |  |  [optional] |
|**link** | **String** |  |  [optional] |
|**rating** | [**SearchResponseResultsInnerRating**](SearchResponseResultsInnerRating.md) |  |  [optional] |
|**adultOnly** | **Boolean** |  |  [optional] |
|**screenshots** | **List&lt;URI&gt;** |  |  [optional] |
|**microTrailer** | **URI** |  |  [optional] |
|**gameplay** | **URI** |  |  [optional] |
|**shortDescription** | **String** |  |  [optional] |



