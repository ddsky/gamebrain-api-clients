

# SearchResponseResultsInnerRating


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**mean** | **BigDecimal** |  |  [optional] |
|**count** | **BigDecimal** |  |  [optional] |



