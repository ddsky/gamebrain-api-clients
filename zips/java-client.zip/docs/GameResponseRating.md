

# GameResponseRating


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**mean** | **Float** |  |  [optional] |
|**count** | **Integer** |  |  [optional] |
|**meanPlayers** | **Float** |  |  [optional] |
|**countPlayers** | **Integer** |  |  [optional] |
|**meanCritics** | **Float** |  |  [optional] |
|**countCritics** | **Integer** |  |  [optional] |



