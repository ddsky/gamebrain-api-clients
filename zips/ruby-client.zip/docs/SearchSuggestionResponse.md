# OpenapiClient::SearchSuggestionResponse

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;SearchSuggestionResponseResultsInner&gt;**](SearchSuggestionResponseResultsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchSuggestionResponse.new(
  results: null
)
```

