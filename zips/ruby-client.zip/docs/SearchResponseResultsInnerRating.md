# OpenapiClient::SearchResponseResultsInnerRating

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **mean** | **Float** |  | [optional] |
| **count** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchResponseResultsInnerRating.new(
  mean: null,
  count: null
)
```

