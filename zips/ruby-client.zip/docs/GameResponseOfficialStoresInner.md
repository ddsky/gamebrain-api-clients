# OpenapiClient::GameResponseOfficialStoresInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **source** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GameResponseOfficialStoresInner.new(
  source: null,
  url: null
)
```

