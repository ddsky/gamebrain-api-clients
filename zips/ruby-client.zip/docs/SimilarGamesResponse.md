# OpenapiClient::SimilarGamesResponse

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;SearchResponseResultsInner&gt;**](SearchResponseResultsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SimilarGamesResponse.new(
  results: null
)
```

