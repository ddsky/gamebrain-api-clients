# OpenapiClient::GameNewsResponse

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **news** | [**Array&lt;GameNewsItem&gt;**](GameNewsItem.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::GameNewsResponse.new(
  news: null
)
```

