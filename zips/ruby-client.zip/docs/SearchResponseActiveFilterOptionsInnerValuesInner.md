# OpenapiClient::SearchResponseActiveFilterOptionsInnerValuesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **match** | **String** |  | [optional] |
| **value** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchResponseActiveFilterOptionsInnerValuesInner.new(
  match: null,
  value: null
)
```

