# OpenapiClient::SearchResponseFilterOptionsInnerValuesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **key** | **String** |  | [optional] |
| **count** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchResponseFilterOptionsInnerValuesInner.new(
  name: null,
  key: null,
  count: null
)
```

