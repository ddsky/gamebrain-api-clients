# SearchResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**i32**> |  | [optional]
**year** | Option<**f64**> |  | [optional]
**name** | Option<**String**> |  | [optional]
**genre** | Option<**String**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**link** | Option<**String**> |  | [optional]
**rating** | Option<[**models::SearchResponseResultsInnerRating**](SearchResponse_results_inner_rating.md)> |  | [optional]
**adult_only** | Option<**bool**> |  | [optional]
**screenshots** | Option<**Vec<String>**> |  | [optional]
**micro_trailer** | Option<**String**> |  | [optional]
**gameplay** | Option<**String**> |  | [optional]
**short_description** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


