# GameResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | Option<**String**> |  | [optional]
**discount_percent** | Option<**f32**> |  | [optional]
**value** | Option<**f32**> |  | [optional]
**initial** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


