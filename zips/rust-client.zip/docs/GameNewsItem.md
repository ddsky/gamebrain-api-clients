# GameNewsItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**url** | **String** |  | 
**source** | **String** |  | 
**image** | Option<**String**> |  | [optional]
**published** | [**String**](string.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


