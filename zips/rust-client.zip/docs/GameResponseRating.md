# GameResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | Option<**f32**> |  | [optional]
**count** | Option<**i32**> |  | [optional]
**mean_players** | Option<**f32**> |  | [optional]
**count_players** | Option<**i32**> |  | [optional]
**mean_critics** | Option<**f32**> |  | [optional]
**count_critics** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


