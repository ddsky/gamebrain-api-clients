# GameResponsePlaytime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentiles** | Option<**Vec<i32>**> |  | [optional]
**min** | Option<**i32**> |  | [optional]
**median** | Option<**i32**> |  | [optional]
**max** | Option<**i32**> |  | [optional]
**mean** | Option<**f32**> |  | [optional]
**mentions** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


