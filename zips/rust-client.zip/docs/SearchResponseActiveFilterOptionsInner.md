# SearchResponseActiveFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | Option<**String**> |  | [optional]
**connection** | Option<**String**> |  | [optional]
**values** | Option<[**Vec<models::SearchResponseActiveFilterOptionsInnerValuesInner>**](SearchResponse_active_filter_options_inner_values_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


