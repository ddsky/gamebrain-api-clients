# SearchResponseResultsInnerRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | Option<**f64**> |  | [optional]
**count** | Option<**f64**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


