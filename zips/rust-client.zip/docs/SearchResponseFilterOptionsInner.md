# SearchResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | Option<**String**> |  | [optional]
**key** | Option<**String**> |  | [optional]
**values** | Option<[**Vec<models::SearchResponseFilterOptionsInnerValuesInner>**](SearchResponse_filter_options_inner_values_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


