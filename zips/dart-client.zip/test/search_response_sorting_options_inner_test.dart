//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchResponseSortingOptionsInner
void main() {
  // final instance = SearchResponseSortingOptionsInner();

  group('test SearchResponseSortingOptionsInner', () {
    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String sort
    test('to test the property `sort`', () async {
      // TODO
    });

    // String key
    test('to test the property `key`', () async {
      // TODO
    });


  });

}
