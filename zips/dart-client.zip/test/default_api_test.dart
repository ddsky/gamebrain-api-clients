//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for DefaultApi
void main() {
  // final instance = DefaultApi();

  group('tests for DefaultApi', () {
    // GET v1/games/{id}
    //
    //Future<GameResponse> detail(int id, String apiKey) async
    test('test detail', () async {
      // TODO
    });

    // GET v1/games
    //
    //Future<SearchResponse> search(String query, int offset, int limit, String filters, String sort, String sortOrder, bool generateFilterOptions, String apiKey) async
    test('test search', () async {
      // TODO
    });

    // GET v1/games/{id}/similar
    //
    //Future<SimilarGamesResponse> similar(int id, int limit, String apiKey) async
    test('test similar', () async {
      // TODO
    });

    // GET v1/games/suggestions
    //
    //Future<SearchSuggestionResponse> suggest(String query, int limit, String apiKey) async
    test('test suggest', () async {
      // TODO
    });

  });
}
