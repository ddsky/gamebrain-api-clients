//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchResponse
void main() {
  // final instance = SearchResponse();

  group('test SearchResponse', () {
    // SearchResponseSorting sorting
    test('to test the property `sorting`', () async {
      // TODO
    });

    // List<SearchResponseActiveFilterOptionsInner> activeFilterOptions (default value: const [])
    test('to test the property `activeFilterOptions`', () async {
      // TODO
    });

    // String query
    test('to test the property `query`', () async {
      // TODO
    });

    // int totalResults
    test('to test the property `totalResults`', () async {
      // TODO
    });

    // int limit
    test('to test the property `limit`', () async {
      // TODO
    });

    // int offset
    test('to test the property `offset`', () async {
      // TODO
    });

    // List<SearchResponseResultsInner> results (default value: const [])
    test('to test the property `results`', () async {
      // TODO
    });

    // List<SearchResponseFilterOptionsInner> filterOptions (default value: const [])
    test('to test the property `filterOptions`', () async {
      // TODO
    });

    // List<SearchResponseSortingOptionsInner> sortingOptions (default value: const [])
    test('to test the property `sortingOptions`', () async {
      // TODO
    });


  });

}
