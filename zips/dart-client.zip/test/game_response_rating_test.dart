//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GameResponseRating
void main() {
  // final instance = GameResponseRating();

  group('test GameResponseRating', () {
    // double mean
    test('to test the property `mean`', () async {
      // TODO
    });

    // int count
    test('to test the property `count`', () async {
      // TODO
    });

    // double meanPlayers
    test('to test the property `meanPlayers`', () async {
      // TODO
    });

    // int countPlayers
    test('to test the property `countPlayers`', () async {
      // TODO
    });

    // double meanCritics
    test('to test the property `meanCritics`', () async {
      // TODO
    });

    // int countCritics
    test('to test the property `countCritics`', () async {
      // TODO
    });


  });

}
