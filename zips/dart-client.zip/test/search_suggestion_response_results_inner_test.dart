//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchSuggestionResponseResultsInner
void main() {
  // final instance = SearchSuggestionResponseResultsInner();

  group('test SearchSuggestionResponseResultsInner', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // num year
    test('to test the property `year`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String genre
    test('to test the property `genre`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String link
    test('to test the property `link`', () async {
      // TODO
    });

    // SearchResponseResultsInnerRating rating
    test('to test the property `rating`', () async {
      // TODO
    });

    // bool adultOnly
    test('to test the property `adultOnly`', () async {
      // TODO
    });


  });

}
