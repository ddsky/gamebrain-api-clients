//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for GameResponsePlaytime
void main() {
  // final instance = GameResponsePlaytime();

  group('test GameResponsePlaytime', () {
    // List<int> percentiles (default value: const [])
    test('to test the property `percentiles`', () async {
      // TODO
    });

    // int min
    test('to test the property `min`', () async {
      // TODO
    });

    // int median
    test('to test the property `median`', () async {
      // TODO
    });

    // int max
    test('to test the property `max`', () async {
      // TODO
    });

    // double mean
    test('to test the property `mean`', () async {
      // TODO
    });

    // int mentions
    test('to test the property `mentions`', () async {
      // TODO
    });


  });

}
