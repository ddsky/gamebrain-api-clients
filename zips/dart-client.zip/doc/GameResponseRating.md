# openapi.model.GameResponseRating

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | **double** |  | [optional] 
**count** | **int** |  | [optional] 
**meanPlayers** | **double** |  | [optional] 
**countPlayers** | **int** |  | [optional] 
**meanCritics** | **double** |  | [optional] 
**countCritics** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


