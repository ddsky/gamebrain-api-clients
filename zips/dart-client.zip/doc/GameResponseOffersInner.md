# openapi.model.GameResponseOffersInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | [**GameResponseOffersInnerPrice**](GameResponseOffersInnerPrice.md) |  | [optional] 
**storeName** | **String** |  | [optional] 
**platform** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**url** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


