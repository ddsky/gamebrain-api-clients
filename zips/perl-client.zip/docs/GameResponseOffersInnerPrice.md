# WWW::OpenAPIClient::Object::GameResponseOffersInnerPrice

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GameResponseOffersInnerPrice;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **string** |  | [optional] 
**discount_percent** | **double** |  | [optional] 
**value** | **double** |  | [optional] 
**initial** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


