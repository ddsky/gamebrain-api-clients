# WWW::OpenAPIClient::Object::SearchResponseFilterOptionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchResponseFilterOptionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**key** | **string** |  | [optional] 
**values** | [**ARRAY[SearchResponseFilterOptionsInnerValuesInner]**](SearchResponseFilterOptionsInnerValuesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


