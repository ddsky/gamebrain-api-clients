# WWW::OpenAPIClient::Object::GameResponsePlatformsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GameResponsePlatformsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **string** |  | [optional] 
**name** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


