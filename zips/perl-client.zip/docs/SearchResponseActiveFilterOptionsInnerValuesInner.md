# WWW::OpenAPIClient::Object::SearchResponseActiveFilterOptionsInnerValuesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchResponseActiveFilterOptionsInnerValuesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**match** | **string** |  | [optional] 
**value** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


