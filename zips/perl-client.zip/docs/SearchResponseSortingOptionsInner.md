# WWW::OpenAPIClient::Object::SearchResponseSortingOptionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchResponseSortingOptionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**sort** | **string** |  | [optional] 
**key** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


