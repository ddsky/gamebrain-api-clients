# WWW::OpenAPIClient::Object::GameResponseOffersInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GameResponseOffersInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | [**GameResponseOffersInnerPrice**](GameResponseOffersInnerPrice.md) |  | [optional] 
**store_name** | **string** |  | [optional] 
**platform** | **string** |  | [optional] 
**title** | **string** |  | [optional] 
**url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


