# WWW::OpenAPIClient::Object::SearchResponseResultsInnerRating

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchResponseResultsInnerRating;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mean** | **double** |  | [optional] 
**count** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


